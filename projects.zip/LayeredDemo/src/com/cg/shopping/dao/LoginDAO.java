package com.cg.shopping.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cg.shopping.model.Login;

public class LoginDAO {
	Connection connection = null;

	public Connection getConnection() {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("resources/db.properties");
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}
		Properties p = new Properties();
		try {
			p.load(fis);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		String driverName = (String) p.get("driverName");
		String url = (String) p.get("url");
		String username = (String) p.get("username");
		String password = (String) p.get("password");
		// 1. Load the JDBC driver
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		// 2. Create a connection to the database
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void newLogin(Login login) {
		String str = "insert into login values(" + Integer.valueOf(login.getId()) + ",'" + login.getUsername() + "','"
				+ login.getPassword() + "','" + login.getRole() + "')";
		System.out.println(str);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e1) {
			System.out.println("Unable to create statement");
			e1.printStackTrace();
		}
		try {
			int r = st.executeUpdate(str);
			if (r == 1) {
				System.out.println("inserted");
			} else {
				System.out.println("NOT inserted");
			}
		} catch (SQLException e) {
			System.out.println(e.getErrorCode());
		}

	}

	public void updateLogin(Login oldLogin, Login newLogin) {
		String str = "update login set uname ='" + newLogin.getUsername() + "', pwd ='" + newLogin.getPassword()
				+ "', role ='" + newLogin.getRole() + "' where id = " + oldLogin.getId();
		System.out.println(str);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			int r = st.executeUpdate(str);
			if (r == 1) {
				System.out.println("Updated");
			} else {
				System.out.println("Not Updated");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void removeLogin(Login login) {
		String query = "delete from login where id = " + login.getId();
		System.out.println(query);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			int r = st.executeUpdate(query);
			if (r == 1) {
				System.out.println("Deleted");
			} else {
				System.out.println("Not Deleted");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Login getLogin(int id) {
		Login login = null;
		connection = getConnection();
		PreparedStatement psmt = null;
		String str = "select * from login where id = ?";
		try {
			psmt = connection.prepareStatement(str, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			psmt.setInt(1, id);
			ResultSet rs = psmt.executeQuery();

			rs.last(); // Move Last
			int size = rs.getRow(); // Find the row
			rs.beforeFirst(); // Move first
			// System.out.println(size);
			if (size == 1) {
				rs.next();
				login = new Login(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			} else {
				System.out.println(id + " does not exist");
			}
		} catch (SQLException e) {
			System.out.println(e);
			// System.out.print(e.getErrorCode() + " ");
			// System.out.println(e.getSQLState());
		}

		return login;
	}

	public List<Login> getAllRows() {
		List<Login> list = new ArrayList<Login>();
		Login login = null;
		connection = getConnection();
		try {
			String query = "select * from login";
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				login = new Login(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
				list.add(login);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}