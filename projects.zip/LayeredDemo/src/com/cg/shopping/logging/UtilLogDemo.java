package com.cg.shopping.logging;

import java.util.logging.Level;
import java.util.logging.Logger;

public class UtilLogDemo {
	private static Logger LOGGER = Logger.getLogger("UtilLogDemo");

	public static void main(String[] args) {
		LOGGER.setLevel(Level.SEVERE);
		LOGGER.config("Logging a CONFIG-level message");
		LOGGER.fine("Logging an FINE-level message");
		LOGGER.finer("Logging an FINER-level message");
		LOGGER.finest("Logging an FINEST-level message");
		LOGGER.info("Logging an INFO-level message");
		LOGGER.warning("Logging an WARNING-level message");
		LOGGER.severe("Logging an SEVERE-level message");
	}

}
