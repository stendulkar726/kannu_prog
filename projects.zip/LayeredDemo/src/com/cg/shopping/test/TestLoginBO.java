package com.cg.shopping.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.shopping.bo.LoginBO;

public class TestLoginBO {
	LoginBO lbo = new LoginBO();

	@Test
	public void testIsValidID() {
		assertTrue(lbo.isValidId("1234"));
		assertFalse(lbo.isValidId("124"));
		assertFalse(lbo.isValidId("12445"));
		assertFalse(lbo.isValidId("124A"));
		assertFalse(lbo.isValidId("A124"));
		assertFalse(lbo.isValidId("@124"));
		assertFalse(lbo.isValidId("124#"));
		assertFalse(lbo.isValidId("abcd"));
		assertFalse(lbo.isValidId("ABCD"));

	}

}
