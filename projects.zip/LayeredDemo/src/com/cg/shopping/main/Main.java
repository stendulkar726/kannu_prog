package com.cg.shopping.main;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.shopping.dao.LoginDAO;
import com.cg.shopping.model.Login;
import com.cgshopping.ui.LoginUI;

public class Main {
	public final static Logger log = Logger.getLogger(Main.class);

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		log.info("Application start.");
		log.info("Main::main() entry");
		Login l = new Login("1010", "xyz", "xyz", "trainee");
		LoginDAO ldao = new LoginDAO();
		ldao.newLogin(l);
		log.info("Main::main() exit");
	}
}
