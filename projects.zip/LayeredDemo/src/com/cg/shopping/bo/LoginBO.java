package com.cg.shopping.bo;

import org.apache.log4j.Logger;

import com.cg.shopping.main.Main;

public class LoginBO {
	private boolean flag = false;
	Logger log = Main.log;

	public boolean isValidId(String id) {
		log.info("LoginBO::isValidId() - id =" + id);
		if (id.length() == 4) {
			log.debug("LoginBO::isValidId() if ");
			char[] ch = id.toCharArray();
			for (char c : ch) {
				if (Character.isDigit(c)) {
					log.debug("LoginBO::isValidId() - inner if");
					flag = true;
				} else {
					log.debug("LoginBO::isValidId() - inner else");
					flag = false;
					break;
				}
			}
		} else {
			log.debug("LoginBO::isValidId() - else");
			flag = false;
		}
		log.info("LoginBO::isValidId() - flag =" + flag);
		return flag;
	}

	public boolean isValidUsername(String username) {
		return flag;
	}

	public boolean isValidPassword(String password) {
		return flag;
	}

	public boolean isValidtRole(String role) {
		return flag;
	}

}
