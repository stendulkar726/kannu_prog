package com.cg.shopping.exception;

public class InvalidIDException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidIDException() {
		super();
	}

	public InvalidIDException(String arg0) {
		super(arg0);
	}
}
