package com.cgshopping.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.shopping.bo.LoginBO;
import com.cg.shopping.exception.InvalidIDException;
import com.cg.shopping.main.Main;
import com.cg.shopping.model.Login;

public class LoginUI {
	private String id;
	private String username;
	private String password;
	private String role;
	Scanner sc = new Scanner(System.in);
	LoginBO lbo = new LoginBO();
	Logger log = Main.log;

	public String getId() {
		log.info("LoginUI::getId() entry");
		System.out.print("Enter Login ID :>");
		id = sc.next();
		if (lbo.isValidId(id)) {
			log.debug("LoginUI::getId() - if");
		} else {
			log.debug("LoginUI::getId() - else");
			try {
				throw new InvalidIDException();
			} catch (InvalidIDException e) {
		log.error("LoginUI::getId() - InvalidIDException ");
				System.out.println("Wrong Input/ID");
				getId();
			}
		}
		log.info("LoginUI::getId() exit - id");
		return id;
	}

	public String getUsername() {
		System.out.print("Enter Username :>");
		username = sc.next();
		return username;
	}

	public String getPassword() {
		System.out.print("Enter Password :>");
		password = sc.next();
		return password;
	}

	public String getRole() {
		System.out.print("Enter Role :>");
		role = sc.next();
		return role;
	}

	public Login getLogin() {
		log.info("LoginUI::getLogin() entry");
		Login login = new Login();
		login.setId(getId());
		login.setUsername(getUsername());
		login.setPassword(getPassword());
		login.setRole(getRole());
		log.info("LoginUI::getLogin()exit return - "+login);
		return login;
	}

	public Login signin() {
		Login login = new Login();
		login.setId(null);
		login.setUsername(getUsername());
		login.setPassword(getPassword());
		login.setRole(null);
		return login;
	}
}
