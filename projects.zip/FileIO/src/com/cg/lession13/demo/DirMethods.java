package com.cg.lession13.demo;

import java.io.File;
import java.util.ArrayList;

public class DirMethods {

	public static void main(String[] args) {
		File f1 = new File("G:\\HCL_60");
		ArrayList<String> dir = new ArrayList<String>();
		ArrayList<String> file = new ArrayList<String>();
		if (f1.isDirectory()) {
			String[] s = f1.list();
			for (String f : s) {
				File f2 = new File("G:\\HCL_60", f);
				if (f2.isDirectory()) {
					dir.add(f);
				}
				if (f2.isFile()) {
					file.add(f);
				}
				// System.out.println(f2.isFile() ? f2.getName() + " is a File" : f2.getName() +
				// " is NOT a File.");
				// System.out.println(f2.isDirectory() ? f2.getName() + " is a dir" :
				// f2.getName() + " is NOT a dir.");
			}
		} else {
			System.out.println(f1.getName() + " is not a dir.");
		}

		System.out.println("Directories");
		System.out.println("-----------");
		for (String d : dir) {
			System.out.println(d);
		}
		System.out.println("Files");
		System.out.println("-----");
		for (String f : file) {
			System.out.println(f);
		}
	}

}
