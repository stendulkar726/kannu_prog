package com.cg.lession13.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileInOutDemo {

	public static void main(String[] args) {
		String str = "This is CapGemini\n";
		File f = new File("mydir","mytxt.txt");
		try {
			FileOutputStream fout = new  FileOutputStream(f, false);
			byte[] b = str.getBytes();
			fout.write(b);
			fout.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
		  FileInputStream fin = new FileInputStream(f);
		  int i=0;
			while ((i = fin.read()) != -1) {
				System.out.print((char) i);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
