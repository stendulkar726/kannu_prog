package com.cg.lession13.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) {
		File f = new File("mydir", "mytxt.txt");
		boolean flag = false;
		if (!f.exists()) {
			try {
				flag = f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (flag) {
				System.out.println("file created.");
			} else {
				System.out.println("Unable to create the file.");
			}
		} else {
			System.out.println("file Already created.");
		}
	}
}
