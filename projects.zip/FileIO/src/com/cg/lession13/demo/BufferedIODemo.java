package com.cg.lession13.demo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedIODemo {

	public static void main(String[] args) {
		File f = new File("mydir","mytxt.txt");
		try {
			FileOutputStream fos = new FileOutputStream(f);
			BufferedOutputStream bos = new BufferedOutputStream(fos);

			String str = " My BufferedOutputStream Example";
			bos.write(str.getBytes());

			System.out.println("File written");

			bos.flush();
			bos.close();
		} catch (FileNotFoundException fnot) {
			System.out.println("Specified file not found" + fnot);
		} catch (IOException ioe) {
			System.out.println("Error while writing file" + ioe);
		}
		try {
			FileInputStream fin = new FileInputStream(f);
			BufferedInputStream bin = new BufferedInputStream(fin);

			byte[] b = new byte[(int) f.length()];
			bin.read(b);
			for (byte c : b) {
				System.out.print((char) c);
			}
			bin.close();
		} catch (FileNotFoundException fnot) {
			System.out.println("Specified file not found" + fnot);
		} catch (IOException ioe) {
			System.out.println("Error while writing file" + ioe);
		}

	}

}
