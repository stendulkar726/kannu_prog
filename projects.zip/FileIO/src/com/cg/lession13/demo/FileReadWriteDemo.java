package com.cg.lession13.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadWriteDemo {

	public static void main(String[] args) {
		String str = "à®Žà®©à¯� à®ªà¯†à®¯à®°à¯� à®•à®£à¯�à®£à®©à¯�\n";
		String str1 = "à°¨à°¾ à°ªà±‡à°°à±� à°•à°¨à±�à°¨à°¨à±�\n";
		try {
			FileWriter fw = new FileWriter("uniFile.txt", false);
			fw.write(str);
			fw.write(str1);
			fw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			File f = new File("uniFile.txt");
			FileReader fr = new FileReader(f);
			int s = (int) f.length();
			char[] ch = new char[s];
			fr.read(ch);
			for (char c : ch) {
				System.out.print(c);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
