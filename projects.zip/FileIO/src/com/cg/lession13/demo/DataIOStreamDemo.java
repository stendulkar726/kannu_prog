package com.cg.lession13.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataIOStreamDemo {
	public static void main(String[] args) {
		File f = new File("mydir", "mytxt.txt");
		try {
			FileOutputStream fos = new FileOutputStream(f);
			DataOutputStream dos = new DataOutputStream(fos);

			int id = 100;
			dos.writeInt(id);
			String name = "Kannan G S";
			dos.writeUTF(name);
			double d = 40000.00;
			dos.writeDouble(d);
			dos.close();
		} catch (IOException e) {
			System.out.println("IOException : " + e);
		}
		try {
			FileInputStream fin = new FileInputStream(f);
			DataInputStream din = new DataInputStream(fin);
			int i = din.readInt();  
			String ch = din.readUTF();
			double d = din.readDouble();  
			System.out.println(i + " - " + ch + " - " + d);
			din.close();
		} catch (FileNotFoundException fe) {
			System.out.println("FileNotFoundException : " + fe);
		} catch (IOException ioe) {
			System.out.println("IOException : " + ioe);
		}

	}
}
