package com.capgemini.lesson13;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharaterDemo {

	public static void main(String[] args) {
		String str = "This is CapGemini\n";
		String str_telugu = "ఇది క్యాప్‌జెమిని\n";
		String str_hindi = "यह कैपजेमिनी है\n";
		// System.out.println(str_telugu);
		// System.out.println(str_hindi);
		File f = new File("mydir", "mytxt.txt");
		try {
			FileWriter fw = new FileWriter(f);
			fw.write(str);
			fw.write(str_telugu);
			fw.write(str_hindi);
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			FileReader fr = new FileReader(f);
			int s = (int) f.length();
			char[] ch = new char[s];
			fr.read(ch);
			for (char c : ch) {
				System.out.print(c);
			}
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
