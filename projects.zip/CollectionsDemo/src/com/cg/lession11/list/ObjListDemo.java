package com.cg.lession11.list;

import java.util.ArrayList;

public class ObjListDemo {

	public static void main(String[] args) {
		Login l1 = new Login("123456", "admin", "admin", "admin");
		Login l2 = new Login("456123", "kannan", "kannan", "trainer");
		Login l3 = new Login("135246", "kumar", "kumar", "trainee");
		Login l4 = new Login("246135", "reena", "reena", "trainee");

		ArrayList<Login> al = new ArrayList<Login>();
		al.add(l1);
		al.add(l2);
		al.add(l3);
		al.add(l4);
		System.out.println(al);
	}

}
