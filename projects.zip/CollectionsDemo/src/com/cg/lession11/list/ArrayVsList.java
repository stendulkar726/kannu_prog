package com.cg.lession11.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayVsList {

	public static void main(String[] args) {
   String[] str = { "one", "two", "three", "four", "five" };
		List<String> strList = Arrays.asList(str);
		
		for (String st : strList) {
			System.out.println(st);
		}
		ArrayList<String> al = new ArrayList<String>(strList);
		al.add("six");
		System.out.println(al);
		al.remove(5);
		System.out.println(al);
	}

}
