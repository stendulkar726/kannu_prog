package com.cg.lession11.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;

public class ListItrDemo {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("A");
		al.add("B");
		al.add("C");
		al.add("D");
		al.add("E");
		al.add("F");
		al.add("G");

		ListIterator<String> litr = al.listIterator();
		System.out.print("\n Forward :> ");
		while (litr.hasNext())
			System.out.print(litr.next() + " ");

		System.out.print("\n Backward :>");
		while (litr.hasPrevious())
			System.out.print(litr.previous() + " ");

		System.out.println();
		while (litr.hasNext()) {
			String str = litr.next();
			if (str.equals("B")) {
				litr.add("b");
			}
			if (str.equals("D")) {
				litr.set("d");
			}
			
		}
		System.out.println(al);
	}

}
