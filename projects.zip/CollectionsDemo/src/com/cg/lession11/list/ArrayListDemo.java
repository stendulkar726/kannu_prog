package com.cg.lession11.list;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("one");
		al.add("two");
		al.add("three");
		al.add("four");
		al.add("five");
		al.add("three");
		System.out.println(al);

		// index base
		System.out.println("Index Based Retrieve");
		String str = al.get(1);
		System.out.println(str);
		System.out.println();

		// Iterator base retrieve
		System.out.println("Iterator Based Retrieve");
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			String sst = (String) itr.next();
			System.out.println(sst);
		}
		System.out.println();

		// for loop retrieve
		System.out.println("For-loop Based Retrieve");
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
		}
		System.out.println();
		// for-each loop retrieve (Java 1.5)
		System.out.println("For-each loop Based Retrieve");
		for (String ss : al) {
			System.out.println(ss);
		}
		System.out.println("----- Java 8.0 -------");
		System.out.println("Iterating by passing lambda expression");
		al.forEach(ss -> System.out.println(ss));

		System.out.println("-------Iterating by passing method reference--------");
		al.forEach(System.out::println);
	}
}
