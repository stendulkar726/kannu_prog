package com.cg.lession11.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GenericDemo {

	public static void main(String[] args) {
		List<String>  list = new ArrayList<String>();
		list.add("1001");
		 
	}

}
