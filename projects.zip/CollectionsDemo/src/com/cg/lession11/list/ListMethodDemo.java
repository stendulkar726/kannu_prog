package com.cg.lession11.list;

import java.util.ArrayList;

public class ListMethodDemo {

	public static void main(String[] args) {
		ArrayList<String> arr1 = new ArrayList<String>();
		arr1.add("A");
		arr1.add("B");
		arr1.add("C");
		ArrayList<String> arr2 = new ArrayList<String>();
		arr2.add("1");
		arr2.add("2");
		arr2.add("3");
		ArrayList<String> al = new ArrayList<String>();

		// al now contains [A,B,C]
		al.addAll(arr1);
		System.out.println(al);

		// al now contains [A,B,C,1,2,3]
		al.addAll(arr2);
		System.out.println(al);

		// al now contains [1,2,3]
		al.retainAll(arr2);
		System.out.println(al);

		// nothing happens - already removed
		boolean f = al.removeAll(arr1);
		if (f) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
		al.removeAll(arr2); // target is now empty.

	}

}
