package com.cg.lession11.list;

import java.util.ArrayList;
public class ListMethods {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		System.out.println("Empty :>"+al.isEmpty());
		al.add("A");
		al.add("B");
		al.add("C");
		al.add("B");
		al.add("D");
		al.add("E");
		al.add("C");
		System.out.println("Size :>"+al.size());
		System.out.println("Contains A :>"+al.contains("A"));
		System.out.println("Contains a :>"+al.contains("a"));
		System.out.println("index of C :>"+al.indexOf("C"));
		System.out.println("last index of C :>"+al.lastIndexOf("C"));
		
		al.add(0, "One");
		System.out.println(al);

		al.set(0, "First");
		System.out.println(al);

		al.remove("First");
		System.out.println(al);
		
		al.remove(3);
		System.out.println("After Deletion:>" + al);
	}
}
