package com.cg.lession11.list;

import java.util.ArrayList;
import java.util.List;

public class ForEachExample {

	public static void main(String[] args) {
		List<String> fruits = new ArrayList<String>();
		fruits.add("Kiwi");
		fruits.add("Banana");
		fruits.add("Apple");
		fruits.add("Cherry");

		System.out.println("------------Iterating for loop --------------");
		for (int i = 0; i < fruits.size(); i++) {
			String fruit = fruits.get(i);
			System.out.println(fruit);
		}
		System.out.println("------------Iterating foreach (Java 1.5) loop --------------");
		for (String fruit : fruits) {
			System.out.println(fruit);
		}

		System.out.println("-----Iterating by passing lambda expression Java 8.0 -------");
		fruits.forEach(fruit -> System.out.println(fruit));

		System.out.println("-------Iterating by passing method reference--------");
		fruits.forEach(System.out::println);
	}
}
