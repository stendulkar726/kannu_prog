package com.cg.lession11.list;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<String>();
		list.add("B");
		list.add("C");
		list.addFirst("A");
		list.add("D");
		list.addLast("E");
		System.out.println(list);
		
		// queue
		System.out.println("getFirst() :>" + list.getFirst());
		System.out.println("getLast() :>" + list.getLast());
		System.out.println("peek() :>" + list.peek());
		System.out.println("peekFirst() :>" + list.peekFirst());
		System.out.println("peekLast() :>" + list.peekLast());

		// stack
		list.push("1");
		System.out.println("push(1) :>");
		System.out.println(list);
		System.out.println("pop() :>" + list.pop());
		System.out.println(list);
	}

}
