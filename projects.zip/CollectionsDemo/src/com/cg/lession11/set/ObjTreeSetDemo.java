package com.cg.lession11.set;

import java.util.Set;
import java.util.TreeSet;

public class ObjTreeSetDemo {

	public static void main(String[] args) {
		Set<Login> ts = new TreeSet<Login>(new IDSort());
		Login l1 = new Login("1008", "reena", "reena", "trainee");
		Login l2 = new Login("1022", "meena", "meena", "trainee");
		Login l3 = new Login("1003", "beena", "beena", "trainee");
		ts.add(l1);
		ts.add(l2);
		ts.add(l3);
		ts.add(l2);
		System.out.println(ts);

	}

}
