package com.cg.lession11.set;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		boolean f = false;
		Set<Integer> ts = new TreeSet<Integer>();
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			int st = sc.nextInt();
			f = ts.add(st);
			if (f) {
				System.out.println("added");
			} else {
				System.out.println("duplicate");
			}
			System.out.println(ts);
		}

	}

}
