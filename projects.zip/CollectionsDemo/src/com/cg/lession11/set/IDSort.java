package com.cg.lession11.set;

import java.util.Comparator;

public class IDSort implements Comparator<Login> {

	@Override
	public int compare(Login l1, Login l2) {
		return Integer.parseInt(l1.getId()) 
				- Integer.parseInt(l2.getId());
	}

}
