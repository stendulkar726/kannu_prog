package com.cg.lession11.set;

import java.util.Comparator;

public class NameSort implements Comparator<Login> {
	@Override
	public int compare(Login l1, Login l2) {
		return l1.getUsername().compareTo(l2.getUsername());
	}

}
