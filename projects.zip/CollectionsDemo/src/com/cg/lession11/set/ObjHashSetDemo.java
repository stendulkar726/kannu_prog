package com.cg.lession11.set;

import java.util.HashSet;
import java.util.Set;

public class ObjHashSetDemo {

	public static void main(String[] args) {
		Set<Login> hs = new HashSet<Login>();
		Login l1 = new Login("1001", "reena", "reena", "trainee");
		Login l2 = new Login("1002", "meena", "meena", "trainee");
		Login l3 = new Login("1003", "beena", "beena", "trainee");
		hs.add(l1);
		hs.add(l2);
		hs.add(l3);
		hs.add(l2);
		System.out.println(hs);
	}

}
