package com.cg.lession11.map;

import java.util.HashMap;
import java.util.Map;

import com.cg.lession11.list.Login;

public class ObjHashMap {

	public static void main(String[] args) {
		Login l1 = new Login("123456", "admin", "admin", "admin");
		Login l2 = new Login("456123", "kannan", "kannan", "trainer");
		Login l3 = new Login("135246", "kumar", "kumar", "trainee");
		Login l4 = new Login("246135", "reena", "reena", "trainee");

		Map<String, Login> map = new HashMap<String, Login>();
		map.put(l1.getId(), l1);
		map.put(l2.getId(), l2);
		map.put(l3.getId(), l3);
		map.put(l4.getId(), l4);
		System.out.println("Keys :>"+map.keySet());
		System.out.println("Values :>"+map.values());
		
		String key = "456123";
		Login v = map.get(key);
		System.out.println(key+"->"+v);
	}

}
