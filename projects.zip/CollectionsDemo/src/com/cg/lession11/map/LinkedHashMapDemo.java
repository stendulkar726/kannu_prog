package com.cg.lession11.map;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("1001", "admin");
		map.put("1002", "kannan");
		map.put("1003", "kumar");
		map.put("1004", "reena");
		map.put("1005", "beena");
		map.put(null, "0");
		map.put(null, "10");
		
		// get()
		String k = null;
		String v = map.get(k);
		System.out.println(k + "->" + v);

		// Retrieving all keys
		System.out.println("Keys of hash map: " + map.keySet());

		// Retrieving all values
		System.out.println("Values of hash map: " + map.values());
	}
}
