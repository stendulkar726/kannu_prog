package com.cg.lession11.map;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapEntryDemo {

	public static void main(String[] args) {
		LinkedHashMap<String, Integer> map = new LinkedHashMap<String, Integer>();

		map.put("1 - Bedroom", 25000);
		map.put("2 - Bedroom", 50000);
		map.put("3 - Bedroom", 75000);
		map.put("1 - Bedroom - Villa", 65000);
		map.put("2 - Bedroom - Villa", 85000);
		map.put("3 - Bedroom - Villa", 105000);

		// � Using entrySet() to get the entry's of the map
		Set<Entry<String, Integer>> set = map.entrySet();
		for (Map.Entry<String, Integer> it : set) {
			// Using the getKey() and getValue() for
			// get key and get value of the it element
			System.out.println("Before Change of value : " + it.getKey() + " " + it.getValue());

			// Changing the value of 1 - Bedroom.
			double getRandom = Math.random() * 100000;
			int getRoundOff = (int) getRandom;

			// Using setValue to change the value of the map element
			it.setValue(getRoundOff);
			
			System.out.println("After Change of value : " + it.getKey() + " " + it.getValue());
		}

	}

}
