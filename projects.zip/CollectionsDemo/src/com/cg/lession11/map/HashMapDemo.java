package com.cg.lession11.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("1001", "admin");
		map.put("1002", "kannan");
		map.put("1003", "kumar");
		map.put("1004", "reena");
		map.put("1005", "beena");
		map.put(null, "0");
		map.put(null, "10");
		map.put("1004", "meena");
		// get()
		String k = "1004";
		String v = map.get(k);
		System.out.println(k + "->" + v);
		//
		// Retrieving all keys
		System.out.println("Keys of hash map: " + map.keySet());
		//
		// Retrieving all values
		System.out.println("Values of hash map: " + map.values());

		// Using a Key Iterator (before 1.5)
		System.out.println("Key Iterator");
		Iterator<String> itr = map.keySet().iterator();
		while (itr.hasNext()) {
			String key = (String) itr.next();
			String value = map.get(key);
			System.out.println(key + "->" + value);
		}
		// � Using entrySet() to get the entry's of the map
		System.out.println("Using Map.Entry");
		Set<Entry<String, String>> set = map.entrySet();
		for (Map.Entry<String, String> it : set) {
			// Using the getKey() and getValue() for
			// get key and get value of the it element
			System.out.println(it.getKey() + " " + it.getValue());
		}

		// Using a For-each loop(after 1.5)
		System.out.println("For-each loop");
		for (String key : map.keySet()) {
			String value = map.get(key);
			System.out.println(key + "=>" + value);
		}
	}

}
