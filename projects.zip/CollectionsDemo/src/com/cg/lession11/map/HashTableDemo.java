package com.cg.lession11.map;

import java.util.Hashtable;

public class HashTableDemo {

	public static void main(String[] args) {
		Hashtable<String, Integer> ht = new Hashtable<String, Integer>();
		ht.put("one", 1);
		ht.put("two", 2);
		ht.put("three", 3);
		 
		Integer n = ht.get("two");
		if (n != null) {
			System.out.println("two = " + n);
		}
	}

}
