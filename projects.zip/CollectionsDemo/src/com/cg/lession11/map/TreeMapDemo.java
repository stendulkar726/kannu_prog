package com.cg.lession11.map;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {
	public static void main(String[] args) {
		TreeMap<Integer, String> days = new TreeMap<Integer, String>();
		days.put(1, "Sunday");
		days.put(2, "Monday");
		days.put(3, "Tueday");
		days.put(4, "Wedday");
		days.put(5, "Thrusday");
		days.put(6, "Friday");
		days.put(7, "Saturday");

		int i = 3;
		String day = days.get(i);
		System.out.println(i + "->" + day);

		// Retrieving the First key and its value
		int fk = days.firstKey();
		String fv = days.get(fk);
		System.out.println("First key/value pair :>"+fk+"->" + fv);

		// Retrieving the Last key and value
		int lk = days.lastKey();
		String lv = days.get(lk);
		System.out.println("Last key/value pair :>" +lk+"->" + lv);
	}
}
