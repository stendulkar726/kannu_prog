package com.cg.lession11.ordered;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemo {
	public static void main(String[] args) {
		Emp e1 = new Emp(1005, "kannan", 40000.00);
		Emp e2 = new Emp(1002, "kumar", 44000.00);
		Emp e3 = new Emp(1001, "reena", 46000.00);
		Emp e4 = new Emp(1003, "meena", 45000.00);
		Emp e5 = new Emp(1004, "beena", 50000.00);
		ArrayList<Emp> al = new ArrayList<Emp>();
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		al.add(e5);
		System.out.println("Before Sort :>");
		for (Emp e : al) {
			System.out.println(e);
		}
		Collections.sort(al, new IDSort());
		System.out.println("After Sort :>");
		for (Emp e : al) {
			System.out.println(e);
		}
	}
}
