package com.cg.lession11.ordered;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionSortDemo {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("one");
		al.add("two");
		al.add("three");
		al.add("four");
		al.add("five");
		al.add("six");
		System.out.println("Before Sort :>"+al);
		Collections.sort(al);
		System.out.println("After Sort :>"+al);
	}

}
