package com.cg.lession11.ordered;

import java.util.Comparator;

public class IDSort implements Comparator<Emp> {

	@Override
	public int compare(Emp e1, Emp e2) {
		// int r = 0;
		// if (e1.getId() < e2.getId()) {
		// r = -1;
		// } else if (e1.getId() > e2.getId()) {
		// r = 1;
		// } else {
		// r = 0;
		// }
		// return r;
		return (e1.getId() < e2.getId()) ? -1 : (e1.getId() > e2.getId()) ? 1 : 0;
	}

}
