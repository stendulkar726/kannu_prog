package com.cg.lession10.array;

public class VarArgsDemo {

	public void show(int i) {
		System.out.println("primitive");
	}

	public void show(Integer i) {
		System.out.println("Wrapper");
	}

	public void show(int... i) {
		System.out.println("var args");
	}

	public void hobbies(String name, double... s) {
		System.out.println("\nName :>" + name);
		System.out.println("\nHobbies ");
		for (double d : s) {
			System.out.println(d);
		}
	}
	public void hobbies(String name, String... hobby) {
		System.out.println("\nName :>" + name);
		System.out.println("\nHobbies ");
		for (String h : hobby) {
			System.out.print(h);
		}
	}
}
