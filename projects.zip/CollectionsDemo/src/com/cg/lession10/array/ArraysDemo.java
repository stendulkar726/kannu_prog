package com.cg.lession10.array;

import java.util.Arrays;

public class ArraysDemo {

	public static void main(String[] args) {
		
		int[] arr = new int[5];
		Arrays.fill(arr, 3);
		for (int i : arr) {
			System.out.println(i);
		}
		System.out.println("After sorting");
		int[] a = { 10, 20, 3, 5, 7 };
		Arrays.sort(a);
		for (int i : a) {
			System.out.print(i+ " ");
		}
	}
}
