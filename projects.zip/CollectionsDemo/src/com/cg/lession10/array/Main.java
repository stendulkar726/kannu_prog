package com.cg.lession10.array;

public class Main {

	public static void main(String[] args) {
		 VarArgsDemo v = new VarArgsDemo();
	 
		 v.hobbies("kumar","criket");
		 v.hobbies("kavitha","vally ball","Chess");
	}

}
