package com.cg.lession4.vardemo;

public class Main {

	public static void main(String[] args) {
		VarType vt = new VarType();
		System.out.println("instance variable " + vt.insVar);
		System.out.println("static   variable " + vt.staticVar);
		vt.show();

	}

}
