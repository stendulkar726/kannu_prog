package com.cg.lession4.vardemo;

public class VarType {
	public int insVar = 100;
	public static int staticVar = 200;
	public void show() {
		int lvar = 300;
		System.out.println("local variable "+lvar);
	}
}
