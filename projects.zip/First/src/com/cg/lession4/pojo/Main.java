package com.cg.lession4.pojo;

public class Main {

	public static void main(String[] args) {
		 Employee e1 = new Employee(1001, "kannan", 50000.00);
		 System.out.println(e1);
	}
}
