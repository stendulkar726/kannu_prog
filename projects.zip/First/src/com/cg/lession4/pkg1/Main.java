package com.cg.lession4.pkg1;

public class Main {

	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.pubVar);
		System.out.println(a.proVar);
		System.out.println(a.defVar);
		a.publicMethod();
		a.protectedMethod();
		a.defMethod();

	}

}
