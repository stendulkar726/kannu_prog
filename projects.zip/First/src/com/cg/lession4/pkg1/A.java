package com.cg.lession4.pkg1;

public class A {
	public int pubVar = 100;
	protected int proVar = 200;
	private int priVar = 300;
	int defVar = 400;

	private void privateMethod() {
		System.out.println("private method");
	}

	protected void protectedMethod() {
		System.out.println("protected method");
	}

	public void publicMethod() {
		System.out.println("public method");
	}

	void defMethod() {
		System.out.println("default method");
	}
}
