package com.cg.lession4.demo;

public class AccountBalance {
	public static void main(String[] args) {
		 Balance obj = new Balance("Kannan", 40000.00);
		 obj.show();
	}
}
