package com.cg.lession4.pkg2;

public class Main {

	public static void main(String[] args) {
		B b = new B();
		b.aceessMod();
		C c = new C();
		c.aceessMod();
	}

}
