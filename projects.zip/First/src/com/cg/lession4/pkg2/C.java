package com.cg.lession4.pkg2;

import com.cg.lession4.pkg1.A;

public class C extends A {
	public void aceessMod() {
		C c = new C();
		System.out.println(c.pubVar);
		System.out.println(c.proVar);
		// System.out.println(c.defVar);
		c.publicMethod();
		c.protectedMethod();
		// c.defMethod();
	}
}
