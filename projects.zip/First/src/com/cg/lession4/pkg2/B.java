package com.cg.lession4.pkg2;

import com.cg.lession4.pkg1.A;

public class B {
	public void aceessMod() {
		A a = new A();
		System.out.println(a.pubVar);
		a.publicMethod();
	}
}
