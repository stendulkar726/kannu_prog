package com.cg.lession4.constructordemo;

public class Employee {
	public int id;
	public String name;
	public double salary;
	//default
	public Employee() {
		super();
		this.id = 0;
		this.name = null;
		this.salary = 0.0;
	}
//paramaeter
	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
//Copy 
	public Employee(Employee e) {
		super();
		this.id = e.id;
		this.name = e.name;
		this.salary = e.salary;
	}

	public void show() {
		System.out.println(id + " " + name + " " + salary);
	}
}
