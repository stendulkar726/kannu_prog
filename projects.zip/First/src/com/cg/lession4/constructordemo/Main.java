package com.cg.lession4.constructordemo;

public class Main {

	public static void main(String[] args) {
		// Employee e1 = new Employee();
		Employee e2 = new Employee(1001, "kannan", 50000.00);
		Employee e3 = new Employee(e2);
		// e1.show();
		e2.show();
		e3.show();

	}
}
