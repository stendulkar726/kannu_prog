package com.cg.funda;

public class BreakDemo {

	public static void main(String[] args) {
		int i = 1;
		System.out.println("Before Loop");
		while (i < 10) {
			System.out.print(i + " ");
			if (i==5) {
				break;
			}
			i++;
		}
		System.out.println("\n AfterLoop");
	}
}
