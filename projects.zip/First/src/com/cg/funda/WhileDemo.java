package com.cg.funda;

public class WhileDemo {

	public static void main(String[] args) {
		int i = 1;
		while (i < 11) {
			System.out.print(i + " ");
			i++;
		}
		System.out.println("\n i = " + i);
		i = 1;
		do {
			System.out.print(i + " ");
			i++;
		} while (i < 11);
		System.out.println();
		for (int j = 0; j < 11; j++) {
			System.out.print(j+" ");
		}
	}

}
