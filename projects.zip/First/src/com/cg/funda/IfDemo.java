package com.cg.funda;

public class IfDemo {

	public static void main(String[] args) {
		int age = 18;
		if (age > 18) {
			System.out.println("Major");
		} else {
			System.out.println("Minor");
		}
	}

}
