package com.cg.funda;

public class ContinueDemo {

	public static void main(String[] args) {
		int i = 1;
		while (i < 10) {
			System.out.print(i + " ");
			System.out.println("Before");
			i++;
			if (i == 5) {
				continue;
			}
			System.out.println("After");
		}

	}
}
