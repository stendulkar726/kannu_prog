package com.cg.funda;

public class SwitchDemo {

	public static void main(String[] args) {
		String str = "abc";
		switch (str) {
		case "Abc":
			System.out.println("Abc");
			break;
		case "abc":
			System.out.println("abc");
			break;
		case "ABC":
			System.out.println("ABC");
			break;
		default:
			System.out.println("ERROR");
			break;
		}
	}
}
