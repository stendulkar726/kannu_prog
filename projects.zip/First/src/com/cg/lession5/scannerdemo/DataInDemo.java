package com.cg.lession5.scannerdemo;

import java.util.Scanner;

public class DataInDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Id:>");
		int id = sc.nextInt();
		System.out.print("Enter Name:> ");
		String name = sc.nextLine();
		name = sc.nextLine();
		System.out.print("Enter Salary :>");
		double salary = sc.nextDouble();
		System.out.println(id + " " + name + " earn " + salary);
		System.out.print("Do you want to continue? :>");
		char choice = sc.next().charAt(0);
		if (choice == 'Y' || choice == 'y') {
			System.out.println("Happy to stay with us.");
		} else {
			System.out.println("bye bye...");
		}

	}

}
