package com.cg.lession5.scannerdemo;

import java.util.Scanner;

public class DelimitDemo {

	public static void main(String[] args) {
		String str = "1,2.1,3.33,40.4,5.0,6.6";
		Scanner sc = new Scanner(str).useDelimiter(",");
		System.out.print("Extract int values :> ");
		while (sc.hasNextInt()) {
			int i  = sc.nextInt();
			 System.out.println(i);
		}
		System.out.print("Extract Double Numbers :>");
		while (sc.hasNextDouble()) {
			double d = sc.nextDouble();
			 System.out.print(d+" ");
		}

	}

}
