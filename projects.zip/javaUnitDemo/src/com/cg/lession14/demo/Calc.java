package com.cg.lession14.demo;

public class Calc {
	public int add(int a, int b) {
		return a + b;
	}

	public int div(int a, int b) {
		return a / b;
	}
}
