package com.cg.lession14.demo;

import org.junit.Test;

public class TimeOutDemo {

	@Test(timeout = 100)
	public void test() {
		for (long i = 0; i < 100000; i++);
	}

}
