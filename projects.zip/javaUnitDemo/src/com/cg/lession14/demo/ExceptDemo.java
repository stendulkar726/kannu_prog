package com.cg.lession14.demo;

import org.junit.Ignore;
import org.junit.Test;

public class ExceptDemo {
	@Ignore
	@Test(expected = ArithmeticException.class)
	public void test() {
		int d = 10 / 0;
	}

}
