package com.cg.lession14.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class TestSum {
	Sum s = new Sum();

	@Test
	public void test() {
		assertEquals(30, s.add(10, 20));
		assertNotEquals(200, s.add(10, 20));
		assertNotEquals(-10, s.add(10, 20));
		assertNotEquals(0, s.add(10, 20));
	}
	
	@Test(expected = ArithmeticException.class)
	public void testDiv() {
		assertEquals(3, s.div(10, 3));
		assertNotEquals(13, s.div(10, 0));
	}

	@Test(timeout = 1)
	public void testTime() {
		for (long i = 0; i < 1000000; i++);
	}
}
