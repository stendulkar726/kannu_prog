package com.cg.lession14.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;

import org.junit.Test;

public class TestCalc {
	Calc c = new Calc();

	@Test
	public void testAdd() {
		assertEquals(30, c.add(10, 20));
		assertNotEquals(-10, c.add(10, 20));
		assertNotEquals(200, c.add(10, 20));
		assertNotEquals(0, c.add(10, 20));
		assertNotEquals(0, c.add(10, 20));
	}

	@Test(expected = ArithmeticException.class)
	public void testExcept() {
		assertEquals(0, c.div(10, 0));
	}

	@Test
	public void testDiv() {
		assertEquals(3, c.div(10, 3));
		assertNotEquals(13, c.div(10, 3));
	}

}
