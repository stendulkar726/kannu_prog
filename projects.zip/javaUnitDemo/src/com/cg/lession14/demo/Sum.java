package com.cg.lession14.demo;

public class Sum {
	public int add(int a, int b) {
		return a + b;
	}

	public int div(int a, int b) {
		return a / b;
	}
	
	public void time() {
		for (long i = 0; i < 1000000; i++);
	}
}
