package com.capegemini.lession14.demo;

import org.junit.Test;

public class AccountTest {

	@Test(expected = MinimumBalanceException.class)
	public void test() {
		Account a = new Account(1001, "kannan", 300.0);
	}

}
