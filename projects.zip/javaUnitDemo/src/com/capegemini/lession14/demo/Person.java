package com.capegemini.lession14.demo;

public class Person {
	private String firstName;
	private String lastName;

	public Person(String firstName, String lastName) {
		super();
		if (firstName != null && lastName != null) {
			this.firstName = firstName;
			this.lastName = lastName;
		} else {
			throw new IllegalStateException("names must should NOT null");
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
	public String getFullName() {
		return this.firstName+" "+this.lastName;
	}
}
