package com.capegemini.lession14.demo;

public class Account {
	private int no;
	private String name;
	private double balance;
	
	public Account(int no, String name, double balance) {
		super();
		this.no = no;
		this.name = name;
		if (balance<500) {
			try {
				throw new MinimumBalanceException();
			} catch (MinimumBalanceException e) {
				e.printStackTrace();
			}
		} else {
			this.balance = balance;
		}
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [no=" + no + ", name=" + name + ", balance=" + balance + "]";
	}
	
	
}
