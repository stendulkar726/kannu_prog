package com.capegemini.lession14.demo;

public class Main {

	public static void main(String[] args) {
		 Person p =new Person("Seetharaman","kannan");
		 System.out.println(p.getFullName());

	}

}
