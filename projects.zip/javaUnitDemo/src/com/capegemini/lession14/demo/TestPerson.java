package com.capegemini.lession14.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class TestPerson {

	Person p = new Person("Seetharaman", "kannan");
	@Test
	public void testGetFirstName() {
		assertEquals(p.getFirstName(), "Seetharaman");
	}
	@Test
	public void testGetLastName() {
		assertEquals(p.getLastName(), "kannan");
	}
	@Test
	public void testGetFullName() {
		assertEquals(p.getFullName(),"Seetharaman kannan");
	}
	
	
	@Test
	public void testNotNullsInName() {
		System.out.println("testNotNullsInName");
		assertNotNull(p.getFullName());
		assertNotNull(p.getFirstName());
		assertNotNull(p.getLastName());
	}

	@Test(expected = IllegalStateException.class)
	public void testNullInName() {
		System.out.println("Check Null in Names");
		Person p1 = new Person(null, "Knnan");
		assertNull(p1.getFirstName());
		Person p2 = new Person("Seetharaman", null);
		assertNull(p2.getLastName());
	}
	@Test(expected = IllegalStateException.class)
	public void testNullsInName() {
		System.out.println("from testing exceptions");
		Person per1 = new Person(null, null);
	}

	
}
