package com.capegemini.lession14.demo;

public class MinimumBalanceException extends Exception {

	public MinimumBalanceException() {
		super();
	}

	public MinimumBalanceException(String arg0) {
		super(arg0);
	}

}
