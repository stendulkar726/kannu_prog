package com.capgemini.lesson14;

import static org.junit.Assert.*;

import org.junit.*;

public class TestPerson {
	@Test
	public void testGetFullName() {
		System.out.println("from TestPerson1");
		Person per = new Person("Seetharaman","kannan");;
		assertEquals("Robert King", per.getFullName());
	}

	
	@Test
	public void GetFirstName() {
		Person p = new Person("Seetharaman","kannan");
		assertEquals(p.getFirstName(), "Seetharaman");
	}

	@Test
	public void testGetLastName() {
		Person p = new Person("Seetharaman","kannan");;
		assertEquals(p.getLastName(), "kannan");
	}
	
	
	@Test
	public void testNotNullsInName() {
		System.out.println("testNotNullsInName");
		Person per1 = new Person("Seetharaman","kannan");
		assertNotNull("full name null", per1.getFullName());
		assertNotNull("First name null", per1.getFirstName());
	}

	@Test
	public void testNullInName() {
		System.out.println("Check Null in Names");
		Person per1 = new Person(null, "Kannan");
		assertNull(per1.getFirstName());
		Person per2 = new Person("Seetharaman", null);
		assertNull(per2.getLastName());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testNullsInName() {
		System.out.println("from testing exceptions");
		Person per1 = new Person(null, null);
	}

	
}