package com.capgemini.lesson14;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
public class TestStudent {
	@Test
	public void testGetRollNo() {
		Student s = new Student(100, "Sam", "Dcosta");
		assertEquals(s.getRollNo(), 100);
	}
	@Test
	public void testGetFirstName() {
		Student s = new Student(100, "Sam", "Dcosta");
		assertEquals(s.getFirstName(), "Sam");
	}
	@Test
	public void testGetLastName() {
		Student s = new Student(100, "Sam", "Dcosta");
		assertEquals(s.getLastName(), "Dcosta");
	}
}