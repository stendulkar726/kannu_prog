package com.cg.lession8.demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class valid {

	public static void main(String[] args) {
		String str = "EX01";
		
		Pattern p = Pattern.compile("^[A-Za-z][0-9]&");
		Matcher m = p.matcher(str);
		if (m.find()) {
			System.out.println("Matched");
		} else {
			System.out.println("Not Matched");
		}

	}

}
