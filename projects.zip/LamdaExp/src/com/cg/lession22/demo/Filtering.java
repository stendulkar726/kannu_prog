package com.cg.lession22.demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Filtering {

	public static void main(String[] args) {

		List<String> locations = Arrays
				.asList(new String[] { "Mumbai", "Pune", "Mumbai", "Chennai", "Noida", "Banglore", "Noida" });
		Stream<String> stream = locations.stream();
		List<String> result = stream.filter((location) -> 
		location.length() > 6).collect(Collectors.toList());
		result.stream().forEach((city) -> System.out.println(city));
		
		// Filter(Predict)
		List<Integer> list = Arrays.asList
				(11, 3, 44, 5, 66, 33, 44);
		list.stream().filter(num -> num > 0).
		forEach(num ->System.out.print(num + " "));

		// distinct
		System.out.println("\nDinstinct Values");
		list.stream().distinct().forEach(num -> 
		System.out.print(num + " "));

		// limit(<size>)
		System.out.println("\nDinstinct Values");
		list.stream().limit(4).forEach(num -> 
		System.out.print(num + " "));
	}
}
