package com.cg.lession21.demo;

@FunctionalInterface
public interface Sum {
	public int add(int a, int b);
}
