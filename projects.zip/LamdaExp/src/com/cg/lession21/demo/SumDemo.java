package com.cg.lession21.demo;

public class SumDemo {

	public static void main(String[] args) {
		Sum s1 = (int a, int b) -> {
			return (a + b);
		};
		System.out.println(s1.add(10, 20));

		Sum s2 = (a, b) -> (a + b);
		int r = s2.add(10, 20);
		System.out.println(r);
	}
}
