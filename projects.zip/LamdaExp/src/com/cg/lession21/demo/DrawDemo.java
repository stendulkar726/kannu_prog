package com.cg.lession21.demo;

public class DrawDemo implements Drawable {

	public static void main(String[] args) {
		DrawDemo d = new DrawDemo();
		d.draw();
	}

	@Override
	public void draw() {
		System.out.println("draw()");
	}

}
