package com.cg.lession21.demo;

public class LamdaDemo {

	public static void main(String[] args) {
		// with lambda
		Drawable d2 = () -> {
			System.out.println("Draw");
		};
		d2.draw();
	}

}
