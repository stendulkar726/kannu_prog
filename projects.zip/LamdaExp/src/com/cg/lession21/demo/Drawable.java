package com.cg.lession21.demo;

@FunctionalInterface
public interface Drawable {
	public void draw();
}
