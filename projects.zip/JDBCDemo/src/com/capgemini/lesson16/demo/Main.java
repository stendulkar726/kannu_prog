package com.capgemini.lesson16.demo;

public class Main {

	public static void main(String[] args) {
		LoginDAO ldao = new LoginDAO();
		Login log = ldao.getLogin(1008);
		System.out.println(log);
	}
}
