package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class MetaDataDemo {

	public static void main(String[] args) {
		Connection connection = null;
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		try {
			// Load the JDBC driver
			Class.forName(driverName);
			// Create a connection to the database
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (ClassNotFoundException e) {
			// Could not find the database driver
			System.out.println("ClassNotFoundException : " + e.getMessage());
		} catch (SQLException e) {
			// Could not connect to the database
			System.out.println(e.getMessage());
		}
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from users");

			ResultSetMetaData rsmd = rs.getMetaData();
			int noOfCol = rsmd.getColumnCount();
			for (int i = 1; i < noOfCol; i++) {
				String type = rsmd.getColumnTypeName(i);
				String name = rsmd.getColumnLabel(i);
				int size = rsmd.getColumnDisplaySize(i);
				System.out.println(name + " " + type + "(" + size + ")");
			}

			System.out.printf("\n %6s  %20s %20s %20s", "ID", "Username",
					"Password", "Role");
			System.out.println();
			while (rs.next()) {
				System.out.printf("\n %6d  %20s %20s %20s", rs.getInt(1),
						rs.getString(2), rs.getString(3), rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
