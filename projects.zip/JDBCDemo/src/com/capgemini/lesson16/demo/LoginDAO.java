package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LoginDAO {
	Connection connection = null;
	String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String username = "system"; // You should modify this.
	String password = "system"; // You should modify this.

	public Connection getConnection() {
		// 1. Load the JDBC driver
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		// 2. Create a connection to the database
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void newLogin(Login login) {
		String str = "insert into login values(" + login.getId() + ",'" + login.getUname() + "','" + login.getPwd()
				+ "','" + login.getRole() + "')";
		System.out.println(str);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e1) {
			System.out.println("Unable to create statement");
			e1.printStackTrace();
		}
		try {
			int r = st.executeUpdate(str);
			if (r == 1) {
				System.out.println("inserted");
			} else {
				System.out.println("NOT inserted");
			}
		} catch (SQLException e) {
			System.out.println(e.getErrorCode());
		}

	}

	public void updateLogin(Login oldLogin, Login newLogin) {
		String str = "update login set uname ='" + newLogin.getUname() + "', pwd ='" + newLogin.getPwd() + "', role ='"
				+ newLogin.getRole() + "' where id = " + oldLogin.getId();
		System.out.println(str);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			int r = st.executeUpdate(str);
			if (r == 1) {
				System.out.println("Updated");
			} else {
				System.out.println("Not Updated");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void removeLogin(Login login) {
		String query = "delete from login where id = " + login.getId();
		System.out.println(query);
		connection = getConnection();
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			int r = st.executeUpdate(query);
			if (r == 1) {
				System.out.println("Deleted");
			} else {
				System.out.println("Not Deleted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Login getLogin(int id) {
		Login login = null;
		connection = getConnection();
		PreparedStatement psmt = null;
		String str = "select * from login where id = ?";
		try {
			psmt = connection.prepareStatement(str, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			psmt.setInt(1, id);
			ResultSet rs = psmt.executeQuery();

			rs.last(); // Move Last
			int size = rs.getRow(); // Find the row
			rs.beforeFirst(); // Move first
			// System.out.println(size);
			if (size == 1) {
				rs.next();
				login = new Login(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			} else {
				System.out.println(id + " does not exist");
			}
		} catch (SQLException e) {
			System.out.println(e);
			// System.out.print(e.getErrorCode() + " ");
			// System.out.println(e.getSQLState());
		}

		return login;
	}

	public List<Login> getAllRows() {
		List<Login> list = new ArrayList<Login>();
		Login login = null;
		connection = getConnection();
		try {
			String query = "select * from login";
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				login = new Login(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
				list.add(login);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
