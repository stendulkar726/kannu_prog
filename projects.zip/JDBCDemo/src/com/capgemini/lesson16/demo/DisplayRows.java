package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayRows {

	public static void main(String[] args) {
		Connection connection = null;
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		// 1. Load the JDBC driver
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		// 2. Create a connection to the database
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			// 3. Create Query String
			String query = "select * from login";

			// 4. Create a Statement
			Statement st = connection.createStatement();

			// 5. Execute Query
			ResultSet rs = st.executeQuery(query);
			
			
			String str = String.format("%6s  %-20s %-20s %-20s", 
					"ID", "Username", "Password", "Role");
			System.out.println(str);
			while (rs.next()) {
				System.out.printf("\n %6d  %-20s %-20s %-20s", 
						rs.getInt(1), rs.getString(2), 
						rs.getString(3),rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
