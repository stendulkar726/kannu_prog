package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StmtInsert {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Connection connection = null;
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		try {
			// Load the JDBC driver
			Class.forName(driverName);
			// Create a connection to the database
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (ClassNotFoundException e) {
			// Could not find the database driver
			System.out.println("ClassNotFoundException : " + e.getMessage());
		} catch (SQLException e) {
			// Could not connect to the database
			System.out.println(e.getMessage());
		}
		try {
			Scanner sc = new Scanner(System.in);

			System.out.print("Enter ID :>");
			int no = sc.nextInt();
			System.out.print("Enter New Name  :>");
			String name = sc.next();
//			name = sc.nextLine();
			System.out.print("Enter New Password :>");
			String pwd = sc.next();
			System.out.print("Enter the Role:>");
			String role = sc.next();
			
			Statement st = connection.createStatement();
			String query = "insert into login "
					+ "values("+no+", '"+name+"','"+pwd+"','"+role+"')";
			
			System.out.println(query);
			int row = st.executeUpdate(query);
			System.out.println(row+" row(s) inserted.");

			ResultSet rs = st.executeQuery("select * from login");
			System.out.printf("\n %6s  %20s %20s %20s","ID","Username","Password","Role");
			System.out.println();
			while (rs.next()) {
				System.out.printf("\n %6d  %20s %20s %20s", rs.getInt(1),
						rs.getString(2), rs.getString(3), rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			
			try {
				
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
