package com.capgemini.lesson16.demo;

import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleSavepoint;

public class TransactionDemo {

	public static void main(String[] args) {
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		OracleConnection conn = null;
		OracleSavepoint spoint = null;

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn = (OracleConnection) DriverManager.getConnection(url, username, password);

			DatabaseMetaData dbmd = conn.getMetaData();

			// Check whether Savepoint is supported
			if (dbmd.supportsSavepoints())
				System.out.println("Savepoint is supported");
			else
				System.out.println("Savepoint is not supported");

			// Disabling auto commit mode
			conn.setAutoCommit(false);

			System.out.println("Before Transaction .....");
			Statement stmt0 = conn.createStatement();
			ResultSet rs1 = stmt0.executeQuery("select * from login");

			while (rs1.next()) {
				System.out.println(rs1.getInt(1) + "    " + rs1.getString(2) + "     " + rs1.getString(3));
			}

			spoint = conn.oracleSetSavepoint();

			Statement stmt1 = conn.createStatement();
			int r1 = stmt1.executeUpdate("update login set uname='meena' where id=1011");

			Statement stmt2 = conn.createStatement();
			int r2 = stmt2.executeUpdate("update  login set uname='beena' where id=1005");

			System.out.println("After Transaction .....");
			Statement stmt3 = conn.createStatement();
			ResultSet rs2 = stmt3.executeQuery("select * from login");
			while (rs2.next()) {
				System.out.println(rs2.getInt(1) + "    " + rs2.getString(2) + "     " + rs2.getString(3));
			}
			if (r1 == 1 && r2 == 1) {
				conn.commit();
			} else {
				conn.rollback();
			}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
