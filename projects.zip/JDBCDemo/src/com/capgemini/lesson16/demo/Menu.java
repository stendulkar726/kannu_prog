package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		Menu m = new Menu();
		m.menu();
	}

	public void menu() {
		Scanner sc = new Scanner(System.in);
		int i = 0;
		do {
			System.out.println("1.Display Rows");
			System.out.println("2. Add new Login");
			System.out.println("3. Update Login");
			System.out.println("4. Remove Login");
			System.out.println("0. Exit");
			System.out.println("Enter Your Choice");
			i = sc.nextInt();
			switch (i) {
			case 1:
				display();
				break;
			case 2:
				insert();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 0:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
		} while (i != 0);
	}

	public void insert() {
		Connection conn = getConnection();
		try {
			Statement st = conn.createStatement();
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter ID :>");
			int no = sc.nextInt();
			System.out.print("Enter New Name  :>");
			String name = sc.nextLine();
			name = sc.nextLine();
			System.out.print("Enter New Password :>");
			String pwd = sc.nextLine();
			System.out.print("Enter the Role:>");
			String role = sc.nextLine();

			String query = "insert into users values(" + no + ",'" + name + "','" + pwd + "','" + role + "')";
			// System.out.println(query);
			int row = st.executeUpdate(query);
			System.out.println(row + " row(s) inserted.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void update() {
		Connection conn = getConnection();
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter ID :>");
		int no = sc.nextInt();
		System.out.print("Enter New Name  :>");
		String name = sc.nextLine();
		name = sc.nextLine();
		System.out.print("Enter New Password :>");
		String pwd = sc.nextLine();
		System.out.print("Enter the Role:>");
		String role = sc.nextLine();

		try {
			Statement st = conn.createStatement();
			String query = "update users set uname = '" + name + "',pwd = '" + pwd + "',role = '" + role
					+ "' where id = " + no;
			System.out.println(query);
			int row = st.executeUpdate(query);
			System.out.println(row + " row(s) Updated...");
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
	}

	public void delete() {
		Connection conn = getConnection();
		try {
			Statement st = conn.createStatement();

			System.out.print("Enter ID :>");
			Scanner sc = new Scanner(System.in);
			int no = sc.nextInt();

			String query = "delete from users where id = " + no;
			// System.out.println(query);
			int row = st.executeUpdate(query);
			System.out.println(row + " row(s) deleted.");
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
	}

	public void display() {
		Connection conn = getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from login");
			System.out.printf("\n %6s  %20s %20s %20s", "ID", "Username", "Password", "Role");
			System.out.println();
			while (rs.next()) {
				System.out.printf("\n %6d  %20s %20s %20s", rs.getInt(1), rs.getString(2), rs.getString(3),
						rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() {
		Connection connection = null;
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		try {
			// Load the JDBC driver
			Class.forName(driverName);
			// Create a connection to the database
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Established with Oracle...");
		} catch (ClassNotFoundException e) {
			// Could not find the database driver
			System.out.println("ClassNotFoundException : " + e.getMessage());
		} catch (SQLException e) {
			// Could not connect to the database
			System.out.println(e.getMessage());
		}
		return connection;
	}
}
