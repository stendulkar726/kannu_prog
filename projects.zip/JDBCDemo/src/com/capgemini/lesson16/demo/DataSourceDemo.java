package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.pool.OracleDataSource;

public class DataSourceDemo {
	public static void main(String[] args) {
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		try {
			OracleDataSource ods = new OracleDataSource();
			// Set the user name, password, driver type and network protocol
			ods.setUser(username);
			ods.setPassword(password);
			ods.setDriverType("thin");
			ods.setNetworkProtocol("tcp");
			ods.setURL(url);

			// Retrieve a connection
			Connection conn = ods.getConnection();
			// Create a Statement
			Statement stmt = conn.createStatement();

			// Select the NAME column from the Account_1 table
			ResultSet rset = stmt.executeQuery("select uname from login");

			System.out.println("User Names are:- ");
			// Iterate through the result and print the Account holder names
			while (rset.next())
				System.out.println(rset.getString(1));

			// Close the RseultSet
			rset.close();
			rset = null;

			// Close the Statement
			stmt.close();
			stmt = null;
			// Close the connection
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
