package com.capgemini.lesson16.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Demo {
	private int id;
	private String uname;
	private String pwd;
	private String role;
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		Demo d = new Demo();
		d.menu();
	}

	public void menu() {
		int c = 0;
		do {
			System.out.println("Menu \n ______ \n");
			System.out.println("1.New Login");
			System.out.println("2.Edit Login");
			System.out.println("3.Remove Login");
			System.out.println("4.Display All Logins");
			System.out.println("0.Exit");
			System.out.println("Enter Your Choice :>");
			c = sc.nextInt();
			switch (c) {
			case 1:
				newLogin();
				break;
			case 2:
				editLogin();
				break;
			case 3:
				removeLogin();
				break;
			case 4:
				displayLogin();
				break;
			case 0:
				System.out.println("Bye,Bye");
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
		} while (c > 0 || c < 4);
	}

	public void getLogin() {
		System.out.print("Enter ID :>");
		id = sc.nextInt();
		System.out.print("Enter New Name  :>");
		uname = sc.next();
		System.out.print("Enter New Password :>");
		pwd = sc.next();
		System.out.print("Enter the Role:>");
	role = sc.next();
	}

	public void newLogin() {
		System.out.println("new Login");
		getLogin();
		Connection connect = dbCon();
		Statement st = null;
		try {
			st = connect.createStatement();
		} catch (SQLException e) {
			System.out.println("Unable to create statement");
			e.printStackTrace();
		}
		String query = "insert into login values(" 
		+ id + ", '" + uname + "','" + pwd + "','" + role + "')";

		System.out.println(query);
		int row = 0;
		try {
			row = st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(row + " row(s) inserted.");
	}

	public void editLogin() {
		System.out.println("edit");
		getLogin();
		Connection connect = dbCon();
		Statement st = null;
		  try {
			st = connect.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query = "update login set uname = '" + uname + "',pwd = '"
				+ pwd + "',role = '" + role + "' where id = " + id;
		System.out.println(query);
		int row = 0;
		try {
			row = st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(row + " row(s) Updated...");
	}

	public void removeLogin() {
		System.out.println("reomve");
		System.out.print("Enter ID :>");
		int no = sc.nextInt();
		Connection connect = dbCon();
		Statement st = null;
		  try {
			st = connect.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query = "delete from login where id = " + no;
		// System.out.println(query);
		int row = 0;
		try {
			row = st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(row + " row(s) deleted.");
	}

	public void displayLogin() {
		Connection connect = dbCon();
		try {
			Statement st = connect.createStatement();
			ResultSet rs = st.executeQuery("select * from login");
			String str = String.format("%6s  %-20s %-20s %-20s", "ID", "Username", "Password", "Role");
			System.out.println(str);
			while (rs.next()) {
				System.out.printf("\n %6d  %-20s %-20s %-20s", rs.getInt(1), rs.getString(2), rs.getString(3),
						rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private Connection conn = null;

	public Connection dbCon() {
		String driverName = "oracle.jdbc.OracleDriver"; // for Oracle
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system"; // You should modify this.
		String password = "system"; // You should modify this.

		// Load the JDBC driver
		try {
			Class.forName(driverName);
			System.out.println("Connection Established with Oracle...");
		} catch (ClassNotFoundException e) {
			System.out.println("Could not find the database driver ");
		}
		// Create a connection to the database
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("unable connect to the database");
		}
		return conn;
	}
}
