drop table login;

CREATE TABLE login(
id NUMBER(6) NOT NULL,
uname VARCHAR2(20),
pwd VARCHAR2(20),
role VARCHAR2(20));

insert into login values(1,'admin','admin','admin');
insert into login values(2,'kannan','kannan','trainer');
insert into login values(3,'kumar','kumar','trainee');
insert into login values(4,'reena','reena','trainee');
insert into login values(5,'kavitha','kavitha','trainer');

select * from login;