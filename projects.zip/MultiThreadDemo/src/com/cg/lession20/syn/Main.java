package com.cg.lession20.syn;

public class Main {
	public static void main(String[] args) {
		Display d = new Display();
		MyThread t1 = new MyThread(d, "admin");
		MyThread t2 = new MyThread(d, "kannan");
		t1.start();
		t2.start();
	}
}
