package com.cg.lession20.syn;

public class Display {
	public synchronized void wish(String name) {
		System.out.print("Hello ");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(name);
	}
}
