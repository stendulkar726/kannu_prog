package com.cg.lession20.demo;

public class Purchase extends Thread {
	public Purchase(String s) {
		super(s);
		System.out.println("Purchase Thread :> " + this);
		start();
	}

	public void run() {
		for (int i = 5; i > 0; i--) {
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Exception : " + e);
			}
			SynchronizedDemo.request((int) (Math.random() * 10));
		}
	}
}
