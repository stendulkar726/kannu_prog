package com.cg.lession20.demo;

public class MyThread extends Thread {

	Thread t;
	String name;

	public MyThread(String tname) {
		name = tname;
		t = new Thread(this, tname);
		if (name.equals("Two")) {
			t.setPriority(10);
		}
		System.out.println("New Thread : " + t);
		t.start();
	}

	@Override
	public void run() {
		// try {
		// for (int i = 5; i > 0; i--) {
		// System.out.println(name + " " + i);
		// Thread.sleep(2000);
		// }
		// } catch (InterruptedException e) {
		// System.out.println(name + " Interrupted and Exit.");
		// }
	}
}
