package com.cg.lession20.demo;

public class HelloThread extends Thread {
	@Override
	public void run() {
		Thread t = Thread.currentThread();
		System.out.print("Thread name:>" + t.getName());
		System.out.println("  Hello... Welcome to CapGemini");
	}

	public static void main(String[] args) {
		HelloThread ht = new HelloThread();
		ht.start();
		Thread t = Thread.currentThread();
		try {
			t.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ht.run();
	}

}
