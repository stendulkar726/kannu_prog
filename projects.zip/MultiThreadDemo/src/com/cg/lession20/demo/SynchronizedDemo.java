package com.cg.lession20.demo;

public class SynchronizedDemo {
	static int qoh = 50, req = 0;
	public static synchronized void request(int order) {
		if (order <= qoh) {
			System.out.println("Quantity Ordered :> " + order);
			qoh = qoh - order;
			req = req + order;
			System.out.println("Quantity on Hand :>" + qoh);
			System.out.println("Ordered Quantity taken away :>" + req);
			System.out.println();
		} else {
			System.out.println("No More Quantity on Hand");
		}
	}
	public static void main(String[] args) {
		Purchase p1 = new Purchase("One");
		Purchase p2 = new Purchase("Two");
		try {
			for (int n = 3; n > 0; n--) {
				System.out.println("Main Thread " + n);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			System.out.println("Main Thread Exit");
		}
	}
}
