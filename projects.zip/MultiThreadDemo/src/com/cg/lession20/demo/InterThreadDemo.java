package com.cg.lession20.demo;

public class InterThreadDemo {
	public static void main(String[] args) {
		Customer c = new Customer();

		Thread t1 = new Thread() {
			public void run() {
				c.withdraw(15000);
			}
		};
		t1.start();

		Thread t2 = new Thread() {
			public void run() {
				c.deposit(10000);
			}
		};
		t2.start();
	}
}
