package com.cg.lession20.demo;

public class MultiThreadMain {

	public static void main(String[] args) {
		System.out.println("Main Thread Start.");
		MyThread t1 = new MyThread("One");
		MyThread t2 = new MyThread("Two");
		MyThread t3 = new MyThread("Three");
		 try {
		 Thread.sleep(11000);
		 } catch (InterruptedException e) {
		 System.out.println("Main Thread Interrupted.");
		 }
		System.out.println("Main Thread Exit");

	}

}
