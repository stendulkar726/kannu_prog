package com.cg.lession20.demo;

public class DeadLockDemo {

	public static void main(String[] args) {
		String s1="Dead",s2="Lock";
		
		NewThread t1 = new NewThread(s1,s2);
		NewThread t2 = new NewThread(s1,s2);
	}

}
