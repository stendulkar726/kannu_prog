package com.cg.lession20.demo;

public class ThreadClsDemo extends Thread {
	static ThreadClsDemo t = null;

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println(" mythread :>"+i);
			try {
				t.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		t = new ThreadClsDemo();
		t.setName("mythread");
		t.start();
		for (int i = 0; i < 5; i++) {
			System.out.print(" main :>"+i);
			try {
				t.sleep(1000);
				System.out.println();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
