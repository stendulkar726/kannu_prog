package com.cg.lession20.demo;

class MaxPri extends Thread {
	public MaxPri(String s) {
		super(s);
		start();
	}

	public void run() {
		Thread t = Thread.currentThread();
		t.setPriority(MAX_PRIORITY);
		int p = t.getPriority();
		System.out.println("Thread Name : " + t.getName());
		System.out.println("Thread Priority : " + p);
	}
}
