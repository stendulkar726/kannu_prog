package com.cg.lession20.demo;

public class SuspendDemo {
	public static void main(String[] args) {
		System.out.println("Main Thread Start.");
		MyThread t1 = new MyThread("One");
		MyThread t2 = new MyThread("Two");
		try{
				Thread.sleep(1000);
				t1.t.suspend();
				System.out.println("Suspending Thread ONE");
				t1.t.resume();
				Thread.sleep(1000);
				System.out.println("Resume Thread ONE");
							 
				t2.t.suspend();
				Thread.sleep(1000);
				System.out.println("Suspending Thread TWO");
				t2.t.resume();
				System.out.println("Resume Thread TWO");
			
		}catch(InterruptedException e){
			System.out.println(" Interrupted an Existing...");
		}
		try{
			System.out.println(" Waiting for Threads to finish...");
			t1.t.join();
			t2.t.join();
		}catch(InterruptedException e){
			System.out.println(" Main Thread  Existing...");
		}
	}

}
