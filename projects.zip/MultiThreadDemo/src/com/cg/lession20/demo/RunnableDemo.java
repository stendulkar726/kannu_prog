package com.cg.lession20.demo;

public class RunnableDemo implements Runnable {
	static Thread t = null;
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println(" mythread :>" + i);
			try {
				t.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}
	public static void main(String[] args) {
		RunnableDemo tr = new RunnableDemo();
		t = new Thread(tr);
		t.setName("mythread");
		t.start();
		for (int i = 0; i < 5; i++) {
			System.out.print(" main :>" + i);
			try {
				t.sleep(1000);
				System.out.println();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	

}
