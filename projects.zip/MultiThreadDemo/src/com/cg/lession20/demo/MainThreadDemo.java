package com.cg.lession20.demo;

public class MainThreadDemo {

	public static void main(String[] args) {
		System.out.println("Main()");
		Thread t = Thread.currentThread();
		System.out.println("Thread name:>" + t.getName());
		System.out.println("Thread Priority :>" + t.getPriority());
		for (int i = 1; i <= 5; i++) {
			System.out.println(i);
			try {
				t.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
