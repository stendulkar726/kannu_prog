package com.cg.lession20.demo;

public class PriorityDemo {
	public static void main(String[] args) {
		Thread t = Thread.currentThread();
		System.out.println("Thread Name : " + t.getName());
		System.out.println("Thread Priority : " + t.getPriority());
		MaxPri maxp = new MaxPri("Maximum Priority");
		MinPri minp = new MinPri("Minimum Priority");
	}
}
