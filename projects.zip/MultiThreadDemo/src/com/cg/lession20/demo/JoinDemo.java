package com.cg.lession20.demo;

public class JoinDemo extends Thread {
	@Override
	public void run() {
		System.out.println("run()");
	}

	public static void main(String[] args) {
		System.out.println("main() - start");
		JoinDemo t = new JoinDemo();
		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("main() - exit");
	}
}
