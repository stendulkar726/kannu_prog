package com.cg.lession20.demo;

class DisplayCls {
	public void display(String msg) {
		System.out.print("[" + msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("]");
	}
}

class SynThread extends Thread {
	String msg;
	DisplayCls fobj;

	SynThread(DisplayCls fp, String str) {
		fobj = fp;
		msg = str;
		start();
	}

	public void run() {
		synchronized (fobj) {
			fobj.display(msg);
		}
	}
}

public class Syncro {
	public static void main(String[] args) {
		DisplayCls fnew = new DisplayCls();
		SynThread ss = new SynThread(fnew, "welcome");
		SynThread ss1 = new SynThread(fnew, "new");
		SynThread ss2 = new SynThread(fnew, "programmer");
		ss2.run();
	}
}
