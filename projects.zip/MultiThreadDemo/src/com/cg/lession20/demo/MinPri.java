package com.cg.lession20.demo;

public class MinPri extends Thread {
	public MinPri(String s) {
		super(s);
		start();
	}

	public void run() {
		Thread t = Thread.currentThread();
		t.setPriority(MIN_PRIORITY);
		int p = t.getPriority();
		System.out.println("Thread Name : " + t.getName());
		System.out.println("Thread Priority : " + p);
	}
}